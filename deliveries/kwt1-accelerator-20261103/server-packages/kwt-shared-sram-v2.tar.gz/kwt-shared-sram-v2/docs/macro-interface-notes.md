# RAMSP4096X16接口截图核对

日期：2026-11-03。证据为用户在服务器执行grep后的五张截图；未下载或读取完整商业模型，不表示完成仿真或时序验证。本次仅归档事实，不修改RTL，不推送GitHub。

## 已确认

- 服务器文件：/storage1/admin_public_dir/SRAM_Lib_2025/RAMSP4096X16/verilog/RAMSP4096X16_rtl.v 和 RAMSP4096X16.v。
- wrapper为RAMSP4096X16_rtl_top；外部Q[15:0]输出，CLK、CEN、GWEN、RET1N为单比特输入，WEN[15:0]、A[11:0]、D[15:0]、EMA[2:0]、EMAW[1:0]为输入。
- wrapper中Q=Q0，DI=D，例化RAMSP4096X16_fr_top并传递所示端口。
- 底层模块名RAMSP4096X16，BITS=16、WORDS=4096、MUX=8、MEM_WIDTH=128、MEM_HEIGHT=512、WP_SIZE=1；POWER_PINS条件下还有VDDCE、VDDPE、VSSE。
- 内部reg[127:0] mem[0:511]是模型内部组织，不代表对外128位数据口；总位数仍为4096*16。
- 同文件第83/85行及481/483行出现同名模块声明；现有截图不足以核对外层条件编译边界，不能据此报重复模块错误，也不能同时抽取两段当独立源码编译。

## 候选拼接（尚未实施/冻结）

一颗4096*16=8192B；每组两颗并宽形成4096*32=16384B，32组沿深度拼接形成131072*32=524288B。合计64颗。逻辑字地址17位，其中高5位选组、低12位选宏内行。只选中被访问组，读返回保留组标签；32位字节写掩码需要转换到两个16位宏的写掩码，极性须核实。

拟用于SoC侧512KiB共享SRAM，不替代加速器已有20KiB内部X/W宏，不改变其计算架构。控制器原型见integration/e203/shared_ram_dev，但尚未接入服务器SoC。

## 待核对

4096型号的完整wrapper链、功能/时序模式的条件编译、CEN/GWEN/WEN极性、同步读访问延迟、待机Q、写时Q、EMA/EMAW表征条件、建立保持要求、匹配库和PVT。1024/128宏已经通过的EMA2/EMAW0不自动推广到4096；本次不宣称150MHz、面积或功耗通过。平台参考PDF的共享RAM及地址要求仍需核对。

## 截图身份

- `C:\Users\asus\AppData\Local\Temp\codex-clipboard-4e28b645-3792-435e-a7c1-c801453b6f4e.png`；SHA256 `450c848a13bd68727ce77db350718bcaf11e77310d5387091387f7ff3a6abca8`。
- `C:\Users\asus\AppData\Local\Temp\codex-clipboard-78a9ba9a-954f-45e5-ac20-6bdeea76a6eb.png`；SHA256 `b971af30479c2c3c77c80985e567ff31de126e338ceb1520eec3f7c7c2d51460`。
- `C:\Users\asus\AppData\Local\Temp\codex-clipboard-cef5a327-cdea-42ef-816e-f2810f6725cf.png`；SHA256 `20c0e4c41d29bd29d4ebf54f4bdf2aa8def04c6a83f4fff5d92be5eb71c05cbb`。
- `C:\Users\asus\AppData\Local\Temp\codex-clipboard-4f3e288c-446a-475d-9b66-0d637bad39f3.png`；SHA256 `8d91526671002d854fb841dfd4ee9928e87292a4102abe57a3016a8ab1aa211e`。
- `C:\Users\asus\AppData\Local\Temp\codex-clipboard-81908b84-60a6-486d-be3d-7479d2388033.png`；SHA256 `3a378b2c421bc4b940cdcaa77bc13bc884b0b1c05024fa2304f19baf16d96a06`。

## 补充：4096宏快速功能模式已确认

用户随后提供服务器grep截图：RAMSP4096X16.v第59行注释明确ARM_UD_MODEL选择Fast Functional Model，第60行为该宏的ifdef。第57行同时可见ARM_MEM_HOLD=0.500；仅凭定义不能判定各分支中时序检查是否启用。VCS功能编译可采用+define+ARM_UD_MODEL；仍需读取相关实现/手册并实际运行单颗宏及wrapper测试，不能宣称4096功能测试、EMA配置或150MHz STA已通过。

截图：`C:\Users\asus\AppData\Local\Temp\codex-clipboard-4fdbae5d-8e8d-4018-bb63-d281f18b6b3c.png`；SHA256：`c872ce494314df3b076eee6f123e5f40dc4b6436d0fd8d3531890ae1d3843b05`。
